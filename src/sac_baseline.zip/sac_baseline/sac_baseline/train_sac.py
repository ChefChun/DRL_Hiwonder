#!/home/ubuntu/envs/ros/bin/python
from stable_baselines3 import SAC
from hiwonder_jetacker_env import HiwonderJetAckerEnv

def main():
    env = HiwonderJetAckerEnv()
    model = SAC("MlpPolicy", env, verbose=1)
    model.learn(total_timesteps=100_000)
    model.save("sac_jetacker")

if __name__ == "__main__":
    main()