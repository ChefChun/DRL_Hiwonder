import gymnasium as gym
import numpy as np
from gymnasium import spaces
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
import threading
import time


class ROSNode(Node):
    def __init__(self):
        super().__init__('rl_agent')
        self.scan_data = np.ones(270) * 10.0  # match observation_space shape
        self.odom_pose = None
        self.scan_sub = self.create_subscription(LaserScan, 'scan', self.scan_callback, 10)
        self.odom_sub = self.create_subscription(Odometry, 'odom', self.odom_callback, 10)
        self.cmd_pub = self.create_publisher(Twist, 'controller/cmd_vel', 10)

    def scan_callback(self, msg):
        # Ensure data is float64 or float32 matching observation_space dtype
        self.scan_data = np.array(msg.ranges, dtype=np.float64)

    def odom_callback(self, msg):
        pos = msg.pose.pose.position
        self.odom_pose = np.array([pos.x, pos.y], dtype=np.float64)


class HiwonderJetAckerEnv(gym.Env):
    metadata = {"render_modes": [], "render_fps": 30}

    def __init__(self):
        rclpy.init()
        self.node = ROSNode()
        self.spin_thread = threading.Thread(target=rclpy.spin, args=(self.node,), daemon=True)
        self.spin_thread.start()

        # Observation space matches actual scan length & dtype
        self.observation_space = spaces.Box(low=0.0, high=10.0, shape=(270,), dtype=np.float32)
        self.action_space = spaces.Box(low=np.array([0.0, -1.0], dtype=np.float32),
                                       high=np.array([0.3, 1.0], dtype=np.float32),
                                       dtype=np.float32)

        self.goal = np.array([2.0, 0.0], dtype=np.float32)
        self.prev_distance = None

    def reset(self, *, seed=None, options=None, **kwargs):
        # Optional: handle seed for reproducibility if needed
        # self.seed(seed)

        self.node.scan_data = np.ones(270, dtype=np.float64) * 10.0
        time.sleep(1.0)

        obs = np.array(self.node.scan_data, dtype=self.observation_space.dtype)
        obs = np.clip(obs, self.observation_space.low, self.observation_space.high)
        self.prev_distance = self._get_distance()

        info = {}
        return obs, info

    def step(self, action):
        cmd = Twist()
        cmd.linear.x = float(action[0])
        cmd.angular.z = float(action[1])
        self.node.cmd_pub.publish(cmd)

        time.sleep(0.1)  # allow time for robot to act

        obs = np.array(self.node.scan_data, dtype=self.observation_space.dtype)
        obs = np.clip(obs, self.observation_space.low, self.observation_space.high)

        done = self._check_done(obs)
        reward = self._compute_reward(obs)

        terminated = done       # episode ended normally
        truncated = False      # no truncation logic here

        info = {}

        return obs, reward, terminated, truncated, info

    def _compute_reward(self, obs):
        dist = self._get_distance()
        if dist is None:
            return -1.0
        reward = self.prev_distance - dist
        self.prev_distance = dist
        return reward

    def _get_distance(self):
        if self.node.odom_pose is None:
            return None
        return np.linalg.norm(self.node.odom_pose - self.goal)

    def _check_done(self, obs):
        if np.any(obs < 0.2):
            return True
        dist = self._get_distance()
        if dist is None:
            return False  # or True if you want to consider not having odom as done
        return dist < 0.3

    def close(self):
        rclpy.shutdown()
