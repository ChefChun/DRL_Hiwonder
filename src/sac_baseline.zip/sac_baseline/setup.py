from setuptools import setup

package_name = 'sac_baseline'

setup(
    name=package_name,
    version='0.0.1',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', [f'resource/{package_name}']),
        (f'share/{package_name}', ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Your Name',
    maintainer_email='your.email@example.com',
    description='SAC reinforcement learning baseline for JetAcker',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'train_sac = sac_baseline.train_sac:main',  # adjust to your script/module
        ],
    },
)
